﻿// Examples.cpp : Определяет точку входа для приложения.
//

#include "framework.h"
#include "Examples.h"
#include "Object.h"
#include "D3D.h"
#define MAX_LOADSTRING 100

// Глобальные переменные:
HWND m_hwnd;
HANDLE hTread;
BOOL ExitRender = TRUE;//Выйти из потока рендеринга
DWORD dwTreadId;
HINSTANCE hInst;                                // текущий экземпляр
WCHAR szTitle[MAX_LOADSTRING];                  // Текст строки заголовка
WCHAR szWindowClass[MAX_LOADSTRING];            // имя класса главного окна
D3D* D3d = NULL;
FLOAT time0 = 0;
//переменные для буфера объекта
VERTEX* Triangle =NULL;
unsigned long* Indices=NULL;
UINT count_vertex=0;
UINT count_indices = 0;
D3D11_BUFFER_DESC vertexBufferDesc, indexBufferDesc;
D3D11_SUBRESOURCE_DATA vertexData, indexData;
ID3D11Buffer* VBuffer = NULL;
ID3D11Buffer* IBuffer = NULL;
ID3D11Buffer* CBuffer0 = NULL;
//переменные шейдеров
ID3D11VertexShader* VShader=NULL;
ID3D11InputLayout* Layout=NULL;
ID3D11PixelShader* PShader=NULL;
//переменные состояния
ID3D11RasterizerState* Rasterstate=NULL;
ID3D11DepthStencilState* Depthstencilstate=NULL;
ID3D11SamplerState* Samplerstate = NULL;
ID3D11BlendState* BlendstateAlphaOff = NULL;
ID3D11BlendState* BlendstateAlphaOn = NULL;
//Текстуры
ID3D11ShaderResourceView* Texture=NULL;
ID3D11ShaderResourceView* TextureAlpha = NULL;
//Матрицы
XMFLOAT4X4 project;
XMFLOAT4X4 view;
XMFLOAT4X4 view_project;
XMFLOAT4X4 world;
//Источники света
LIGHT Light;
// Отправить объявления функций, включенных в этот модуль кода:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);
    // Инициализация глобальных строк
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_EXAMPLES, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);
    // Выполнить инициализацию приложения:
    if (!InitInstance(hInstance, nCmdShow))
    {
        return FALSE;
    }
    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_EXAMPLES));

    MSG msg;
    // Цикл основного сообщения:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    StopTread();
    CloseHandle(hTread);
    delete D3d;
    return (int)msg.wParam;
}
//
//  ФУНКЦИЯ: MyRegisterClass()
//
//  ЦЕЛЬ: Регистрирует класс окна.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_EXAMPLES));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_EXAMPLES);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));
    return RegisterClassExW(&wcex);
}
//
//   ФУНКЦИЯ: InitInstance(HINSTANCE, int)
//
//   ЦЕЛЬ: Сохраняет маркер экземпляра и создает главное окно
//
//   КОММЕНТАРИИ:
//
//        В этой функции маркер экземпляра сохраняется в глобальной переменной, а также
//        создается и выводится главное окно программы.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    SetThreadDpiAwarenessContext(DPI_AWARENESS_CONTEXT_SYSTEM_AWARE);
    hInst = hInstance; // Сохранить маркер экземпляра в глобальной переменной 

    HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, 1000, 1000, nullptr, nullptr, hInstance, nullptr);
    if (!hWnd)
    {
        return FALSE;
    }
    m_hwnd = hWnd;
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
    D3d = new D3D();
    RECT rect = { 0 };
    GetWindowRect(hWnd, &rect);

    if(FAILED(D3d->Initialize((UINT)(rect.right - rect.left), (UINT)(rect.bottom - rect.top), TRUE, hWnd, FALSE))) return FALSE;
   //Вершины куба и плоскости

    //CreateCubePoligon();
    CreateSphere(6400);
    // Set up the description of the dynamic vertex buffer.
    vertexBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
    vertexBufferDesc.ByteWidth = sizeof(VERTEX) * count_vertex;
    vertexBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
    vertexBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    vertexBufferDesc.MiscFlags = 0;
    vertexBufferDesc.StructureByteStride = 0;
    // Give the subresource structure a pointer to the vertex data.
    vertexData.pSysMem = Triangle;
    vertexData.SysMemPitch = 0;
    vertexData.SysMemSlicePitch = 0;
    // Set up the description of the static index buffer.
    indexBufferDesc.Usage = D3D11_USAGE_DEFAULT;
    indexBufferDesc.ByteWidth = sizeof(unsigned long) * count_indices;
    indexBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
    indexBufferDesc.CPUAccessFlags = 0;
    indexBufferDesc.MiscFlags = 0;
    indexBufferDesc.StructureByteStride = 0;
    // Give the subresource structure a pointer to the index data.
    indexData.pSysMem = Indices;
    indexData.SysMemPitch = 0;
    indexData.SysMemSlicePitch = 0;
    if (FAILED(D3d->device->CreateBuffer(&vertexBufferDesc, &vertexData, &VBuffer))) return FALSE;
    if (FAILED(D3d->device->CreateBuffer(&indexBufferDesc, &indexData, &IBuffer))) return FALSE;
    //Загрузка вершинного шейдера
    ID3D10Blob* errorMessage=NULL;
    ID3D10Blob* vertexShaderBuffer=NULL;
    if (FAILED(D3DReadFileToBlob(L"VSEx2.cso", &vertexShaderBuffer))) return FALSE;
    // Create the vertex shader from the buffer.
    if (FAILED(D3d->device->CreateVertexShader(vertexShaderBuffer->GetBufferPointer(), vertexShaderBuffer->GetBufferSize(), NULL,
        &VShader))) return FALSE;
    D3D11_INPUT_ELEMENT_DESC* desc = NULL;
    UINT numElements;
    numElements = 4;
    desc = new D3D11_INPUT_ELEMENT_DESC[numElements];
    desc[0].SemanticName = "POSITION";
    desc[0].SemanticIndex = 0;
    desc[0].Format = DXGI_FORMAT_R32G32B32_FLOAT; 
    desc[0].InputSlot = 0;
    desc[0].AlignedByteOffset = 0;
    desc[0].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
    desc[0].InstanceDataStepRate = 0;

    desc[1].SemanticName = "NORMAL";
    desc[1].SemanticIndex = 0;
    desc[1].Format = DXGI_FORMAT_R32G32B32_FLOAT;
    desc[1].InputSlot = 0;
    desc[1].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;
    desc[1].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
    desc[1].InstanceDataStepRate = 0;

    desc[2].SemanticName = "COLOR";
    desc[2].SemanticIndex = 0;
    desc[2].Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    desc[2].InputSlot = 0;
    desc[2].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;
    desc[2].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
    desc[2].InstanceDataStepRate = 0;
    
    desc[3].SemanticName = "TEXCOORD";
    desc[3].SemanticIndex = 0;
    desc[3].Format = DXGI_FORMAT_R32G32_FLOAT;
    desc[3].InputSlot = 0;
    desc[3].AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;
    desc[3].InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
    desc[3].InstanceDataStepRate = 0;
    HRESULT result = D3d->device->CreateInputLayout(desc, numElements, vertexShaderBuffer->GetBufferPointer(),
        vertexShaderBuffer->GetBufferSize(), &Layout);
    delete[] desc;
    ReleaseCOM(vertexShaderBuffer);
    
    if (FAILED(result)) return FALSE;
    //Загрузка пиксельного шейдера
    ID3D10Blob* pixelShaderBuffer = NULL;
    if(FAILED(D3DReadFileToBlob(L"PSEx2.cso", &pixelShaderBuffer))) return FALSE;
    result = D3d->device->CreatePixelShader(pixelShaderBuffer->GetBufferPointer(), pixelShaderBuffer->GetBufferSize(), NULL,
        &PShader);
    ReleaseCOM(pixelShaderBuffer);
    if (FAILED(result)) return FALSE;
    D3D11_RASTERIZER_DESC descr;
    descr.AntialiasedLineEnable = FALSE;
    descr.CullMode = D3D11_CULL_NONE;
    descr.DepthBias = 0;
    descr.DepthBiasClamp = 0.0f;
    descr.DepthClipEnable = 1;
    descr.FillMode = D3D11_FILL_SOLID;
    descr.FrontCounterClockwise = 0;
    descr.MultisampleEnable = 0;
    descr.ScissorEnable = 0;
    descr.SlopeScaledDepthBias = 0.0f;
    if (FAILED(D3d->device->CreateRasterizerState(&descr, &Rasterstate))) return FALSE;
    D3D11_DEPTH_STENCIL_DESC descz;
    descz.DepthEnable = TRUE;
    descz.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
    descz.DepthFunc = D3D11_COMPARISON_LESS;
    descz.StencilEnable = 0;
    descz.StencilReadMask = 255;
    descz.StencilWriteMask = 255;
    descz.FrontFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
    descz.FrontFace.StencilDepthFailOp = D3D11_STENCIL_OP_INCR;
    descz.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
    descz.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
    descz.BackFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
    descz.BackFace.StencilDepthFailOp = D3D11_STENCIL_OP_DECR;
    descz.BackFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
    descz.BackFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
    if (FAILED(D3d->device->CreateDepthStencilState(&descz, &Depthstencilstate))) return FALSE;
    D3D11_SAMPLER_DESC descs;
    descs.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    descs.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
    descs.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
    descs.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
    descs.MipLODBias = 0.0f;
    descs.MaxAnisotropy = 1;
    descs.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
    descs.BorderColor[0] = 0;
    descs.BorderColor[1] = 0;
    descs.BorderColor[2] = 0;
    descs.BorderColor[3] = 0;
    descs.MinLOD = 0;
    descs.MaxLOD = D3D11_FLOAT32_MAX;
    if (FAILED(D3d->device->CreateSamplerState(&descs, &Samplerstate))) return FALSE;
    D3D11_BLEND_DESC descb;
    descb.AlphaToCoverageEnable = FALSE;
    descb.IndependentBlendEnable = FALSE;
    descb.RenderTarget[0].BlendEnable = FALSE;
    descb.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
    descb.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
    descb.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    descb.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    descb.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
    descb.RenderTarget[0].BlendOpAlpha=D3D11_BLEND_OP_ADD;
    descb.RenderTarget[0].RenderTargetWriteMask = 15;
    D3d->device->CreateBlendState(&descb, &BlendstateAlphaOff);
    descb.RenderTarget[0].BlendEnable = TRUE;
    D3d->device->CreateBlendState(&descb, &BlendstateAlphaOn);
    //Создать константный буфер
    XMFLOAT4 data = XMFLOAT4(0,0,0,0);
    D3D11_BUFFER_DESC BufferDesc;
    D3D11_SUBRESOURCE_DATA Data;
    BufferDesc.Usage = D3D11_USAGE_DYNAMIC;
    BufferDesc.ByteWidth = sizeof(XMFLOAT4) * 14;
    BufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    BufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    BufferDesc.MiscFlags = 0;
    BufferDesc.StructureByteStride = 0;

    Data.pSysMem = &data;
    Data.SysMemPitch = 0;
    Data.SysMemSlicePitch = 0;

    if(FAILED(D3d->device->CreateBuffer(&BufferDesc, &Data, &CBuffer0))) return FALSE;
    //Загрузка текстуры
    HRESULT hr;

    TexMetadata imageMetadata;
    ScratchImage* image = new ScratchImage();
    hr = LoadFromDDSFile(L"wood2.dds", DDS_FLAGS_NONE, &imageMetadata, *image);
    hr = CreateShaderResourceView(D3d->device, image->GetImages(), image->GetImageCount(), imageMetadata, &Texture);
    delete image;
    if (FAILED(hr)) return FALSE;

    image = new ScratchImage();
    hr = LoadFromDDSFile(L"win3.dds", DDS_FLAGS_NONE, &imageMetadata, *image);
    hr = CreateShaderResourceView(D3d->device, image->GetImages(), image->GetImageCount(), imageMetadata, &TextureAlpha);
    delete image;
    if (FAILED(hr)) return FALSE;
    // Задать источник света
    Light.position = XMFLOAT4(1.8f, 1.8f, 3.0f,1.0f);
    XMFLOAT3 dir = XMFLOAT3(-0.6f, -0.6f, -1.0f);
    XMVECTOR vdir = XMLoadFloat3(&dir);
    XMStoreFloat4(&Light.direction, XMVector3Normalize(vdir));
    Light.color = XMFLOAT4(1.0, 1.0, 1.0, 1.0);
    Light.parametrs = XMFLOAT4(1.0, 0.0f, 0.0f, 0.0f);
    //Создать матрицу перспективной проекции
    XMStoreFloat4x4(&project, XMMatrixPerspectiveFovLH(XM_PIDIV4, 1.0, 0.1f, 100.0f));
    StartTread();//включить рендеринг
    return TRUE;
}
//
//  ФУНКЦИЯ: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  ЦЕЛЬ: Обрабатывает сообщения в главном окне.
//
//  WM_COMMAND  - обработать меню приложения
//  WM_PAINT    - Отрисовка главного окна
//  WM_DESTROY  - отправить сообщение о выходе и вернуться
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // Разобрать выбор в меню:
        switch (wmId)
        {
        case IDM_ABOUT:
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
            break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        EndPaint(hWnd, &ps);
    }
    break;
    case WM_DESTROY:
        StopTread();
        CloseHandle(hTread);
        ReleaseCOM(VBuffer);
        ReleaseCOM(IBuffer);
        ReleaseCOM(CBuffer0);
        ReleaseCOM(VShader);
        ReleaseCOM(Layout);
        ReleaseCOM(PShader);
        ReleaseCOM(Rasterstate);
        ReleaseCOM(Depthstencilstate);
        ReleaseCOM(Samplerstate);
        ReleaseCOM(Texture);
        ReleaseCOM(TextureAlpha);
        ReleaseCOM(BlendstateAlphaOff);
        ReleaseCOM(BlendstateAlphaOn);
        if (Triangle != NULL) delete[] Triangle;
        if (Indices != NULL) delete[] Indices;
        ReleaseMY(D3d);
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}
// Обработчик сообщений для окна "О программе".
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
//Остановить поток рендеринга
VOID StopTread()
{
    if (hTread == NULL) return;
    if (ExitRender)	return;
    ExitRender = TRUE;
    WaitForSingleObject(hTread, INFINITE); // ждём, когда поток реально завершится
    CloseHandle(hTread); // закрываем хендл
    hTread = NULL;
}
//Запустить поток рендеринга
VOID StartTread()
{
    if (hTread != NULL) return;
    if (!ExitRender) return;
    ExitRender = FALSE;
    hTread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)Render, &ExitRender, 0, &dwTreadId);
}
//Поток рендеринга
DWORD WINAPI Render(LPVOID pNeedStop)
{
    while (!(*(bool*)pNeedStop))
    {
        //Мировая матрица
        XMMATRIX world;
        XMMATRIX wy = XMMatrixRotationY(time0 / 60.0f * XM_PIDIV4);
        XMMATRIX wx = XMMatrixRotationX(time0 / 60.0f * XM_PIDIV4 / 2.0f);
        XMMATRIX wz = XMMatrixRotationZ(time0 / 60.0f * XM_PIDIV4 / 3.0f);
        world = XMMatrixMultiply(wy, wx);
        world = XMMatrixMultiply(world, wz);
        world = XMMatrixIdentity();
        //Матрица вида:
        XMFLOAT3 pos = XMFLOAT3(0.0f, 0.0f, 3.0f);
        XMFLOAT3 at = XMFLOAT3(0.0f, 0.0f, -1.0f);
        XMFLOAT3 up = XMFLOAT3(0.0f, 1.0f, 0.0f);
        XMStoreFloat4x4(&view, XMMatrixLookAtLH(XMLoadFloat3(&pos),
            XMLoadFloat3(&at) + XMLoadFloat3(&pos),
            XMLoadFloat3(&up)));
        //Матрица view*proj
        XMStoreFloat4x4(&view_project,
            XMMatrixMultiply(XMLoadFloat4x4(&view),
                XMLoadFloat4x4(&project)));

        //Заполним и установим константный буфер
        D3D11_MAPPED_SUBRESOURCE mappedResource;
        D3d->deviceContext->Map(CBuffer0, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
        XMFLOAT4* temp = (XMFLOAT4*)mappedResource.pData;
        temp[0].x = time0 / 60.0f;// time;
        memcpy(&temp[1], &view_project, sizeof(XMFLOAT4) * 4);
        memcpy(&temp[5], &world, sizeof(XMFLOAT4) * 4);
        memcpy(&temp[9], &Light, sizeof(LIGHT));
        memcpy(&temp[13], &pos, sizeof(XMFLOAT4));
        D3d->deviceContext->Unmap(CBuffer0, 0);
        time0++;
        XMFLOAT4 color = XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f);
        D3d->BeginScene(&color);
        D3d->deviceContext->RSSetState(Rasterstate);
        D3d->deviceContext->OMSetDepthStencilState(Depthstencilstate, 0);
        D3d->deviceContext->PSSetSamplers(0, 1, &Samplerstate);
        float blendFactor[4];
        // Установить фактор смешивания
        blendFactor[0] = 0.0f;
        blendFactor[1] = 0.0f;
        blendFactor[2] = 0.0f;
        blendFactor[3] = 0.0f;
        D3d->deviceContext->OMSetBlendState(BlendstateAlphaOff, blendFactor, 0xffffffff);
        unsigned int stride, offset;
        stride = sizeof(VERTEX);
        offset = 0;
        D3d->deviceContext->IASetVertexBuffers(0, 1, &VBuffer, &stride, &offset);
        D3d->deviceContext->IASetIndexBuffer(IBuffer, DXGI_FORMAT_R32_UINT, 0);
        D3d->deviceContext->VSSetConstantBuffers(0, 1, &CBuffer0);
        D3d->deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        D3d->deviceContext->IASetInputLayout(Layout);
        D3d->deviceContext->VSSetShader(VShader, NULL, 0);
        D3d->deviceContext->PSSetShader(PShader, NULL, 0);
        D3d->deviceContext->PSSetShaderResources(0, 1, &Texture);
        D3d->deviceContext->DrawIndexed(count_indices, 0, 0);
       /*
        D3d->deviceContext->OMSetBlendState(BlendstateAlphaOn, blendFactor, 0xffffffff);
        D3d->deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
        world = XMMatrixIdentity();
        D3d->deviceContext->Map(CBuffer0, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
        temp = (XMFLOAT4*)mappedResource.pData;
        memcpy(&temp[5], &world, sizeof(XMFLOAT4) * 4);
        memcpy(&temp[1], &view_project, sizeof(XMFLOAT4) * 4);
        D3d->deviceContext->Unmap(CBuffer0, 0);
        D3d->deviceContext->VSSetConstantBuffers(0, 1, &CBuffer0);
        D3d->deviceContext->PSSetShaderResources(0, 1, &TextureAlpha);
        D3d->deviceContext->DrawIndexed(4, 36, 0);
        */
        D3d->EndScene();
    }
    return 0;
}